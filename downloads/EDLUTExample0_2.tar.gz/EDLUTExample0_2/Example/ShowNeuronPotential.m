% This script shows the neuron potential of the 3 simulated cells
% More information in http://edlut.googlecode.com.
% Jesús Garrido Alcázar - jgarrido@atc.ugr.es

% Output file
DataFile = './register.dat';

% Layer's cell number
Layers = [0 1 2]

% Load the output file
Data = load(DataFile);

% Set the maximum simulation time
lx=max(Data(:,1));

InitInterval = 0;
FinishInterval = lx;
    
figure;


for i=1:length(Layers),

  %% Find the events which are spikes
  ispk=find(Data(:,2)==Layers(i));
  Spikes = Data(ispk,:);

  clear ispk;
  subplot(length(Layers),1,i);
  tspk=Spikes(find(Spikes(:,3)>0.5),1);
  stem(tspk,-0.082*ones(length(tspk),1),'.');    
  hold on;

  %% Find the events which are not spikes  
  tpot=Spikes(find(Spikes(:,3)<0.5),1:3);
  plot(tpot(:,1),tpot(:,3),'kx-');

  %% Set the titles, axis and labels
  if i==1
    title('MF Cell');
  elseif i==2
    title('GR Cell');
  elseif i==3
    title('GO Cell');
  end                
            
  ylabel('mV');
  axis([InitInterval FinishInterval -0.08 0.00]);
end
    
xlabel('Time (s)');
clear Data;


hold off;
