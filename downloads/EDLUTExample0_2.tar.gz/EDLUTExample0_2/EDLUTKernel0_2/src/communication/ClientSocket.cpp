/***************************************************************************
 *                           ClientSocket.cpp                              *
 *                           -------------------                           *
 * copyright            : (C) 2009 by Jesus Garrido and Richard Carrillo   *
 * email                : jgarrido@atc.ugr.es                              *
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "../../include/communication/ClientSocket.h"

ClientSocket::ClientSocket(string server_address, unsigned short tcp_port):CdSocket(CLIENT,server_address,tcp_port){
}

ClientSocket::~ClientSocket(){
}